/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_04_Expresiones_y_control_de_flujo_poo;

import java.util.*; //Librería que te permite trabajar con el método Scanner
/**
 *
 * @author Eduardo
 */
public class Principal_Estacionamiento {
    
   public static void main(String[] args) { //Método main
       
       //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR EN LA CLASE
       System.out.println("ASIGNATURA.PROGRAMACIÓN ORIENTADA A OBJETOS\nUNIDAD 04.EXPRESIONES Y CONTROL DE FLUJO\nTAREA 04.\n");
       System.out.println("Bienvenido al Estacionamiento Internacional Felipe Ángeles.");
       
       //Aquí vamos a definir los atributos
       int moneda10, moneda5, moneda2, moneda1, pago, cambio, opcion, costo, horas;
       //Para inicializar un atributo de tipo char se deben colocar comillas simples con un espacio ' '
       char menu = ' ';
       //Aquí vamos a pedir todos los valores que se ingresen desde teclado
       //La variable de nuestro método Scanner es leer
       Scanner leer = new Scanner(System.in);

       //ESTRUCTURA DE CONTROL REPETITIVA DO-WHILE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
       do { 
           costo = 0; //Inicializando un atributo de tipo int sin ningún valor
           horas = 0; //Inicializando un atributo de tipo int sin ningún valor
           System.out.println("¿Cuántas horas utilizaste el estacionamiento?");
           horas = leer.nextInt(); //El valor ingresado desde teclado se guardará en el atributo horas
           costo = horas * 17;
           
           //ESTRUCTURA DE CONTROL DECISIVA IF: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
           if (costo > 999) {
               costo = 999;
           }
           
           //Se define la creación del objeto parking
           Estacionamiento parking = new Estacionamiento(costo, horas);

           //Métodos de mi objeto parking
           parking.Pagos();
           parking.Cambios();
           System.out.println("Bienvenido al Estacionamiento Internacional Felipe Ángeles.");
           System.out.print("Por favor, ingrese la tecla 's' para ingresar al sistema del cajero automático: ");
           menu = leer.next().charAt(0); //El valor ingresado desde teclado se guardará en el atributo menu
        }
       while (menu == 's');
    }
}