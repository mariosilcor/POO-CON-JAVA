/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_04_Expresiones_y_control_de_flujo_poo;

import java.util.*; //Librería que te permite trabajar con el método Scanner
/**
 *
 * @author Eduardo
 */
public class Estacionamiento {
    
    //Se definen los atributos de la Clase Estacionamiento
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    int moneda10, moneda5, moneda2, moneda1, pago, cambio, opcion, costo, horas;
    
    //Se define el método Constructor de la Clase Estacionamiento
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Estacionamiento
    public Estacionamiento(int costo, int horas) {
        
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO 
        this.costo = costo;
        this.horas = horas;
      
    }
    
    public void Pagos() { //Aquí vamos a trabajar con el método que calcule los pagos del estacionamiento
        
        pago = 0; //Inicializando un atributo de tipo int sin ningún valor
        opcion = 0; //Inicializando un atributo de tipo int sin ningún valor
        
        //Aquí vamos a pedir todos los valores que se ingresen desde teclado
        //La variable de nuestro método Scanner es leer
        Scanner leer = new Scanner(System.in);
      
        //ESTRUCTURA DE CONTROL REPETITIVA WHILE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        while (!(pago >= costo)) {
            System.out.println("\nUsted debe: $" + (costo - pago) + ". Elige la opción para tu forma de pago: \n1)$100 \t2)$50 \t3)$20 \n4)$10 \t5)$5 \t6)$2 \t7)$1");
            opcion = leer.nextInt(); //El valor ingresado desde teclado se guardará en el atributo opcion
            
            //ESTRUCTURA DE CONTROL DECISIVA IF ELSEIF ELSE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
            if (opcion == 1) {
                pago = pago + 100;
            }
            
            else {
                if (opcion == 2) {
                    pago = pago + 50;
                }
                
                else {
                    if (opcion == 3) {
                        pago = pago + 20;
                    }
                    
                    else {
                        if (opcion == 4) {
                            pago = pago + 10;
                        }
                        
                        else {
                            if (opcion == 5) {
                                pago = pago + 5;
                            }
                            
                            else {
                                if (opcion == 6) {
                                    pago = pago + 2;
                                }
                                
                                else {
                                    if (opcion == 7) {
                                        pago = pago + 1;
                                    }
                                    
                                    else {
                                        System.out.println("Opción incorrecta");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void Cambios() { //Aquí vamos a trabajar con el método que calcule los cambios del estacionamiento
        
        cambio = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda10 = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda5 = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda2 = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda1 = 0; //Inicializando un atributo de tipo int sin ningún valor
        cambio = pago - costo;
        
        //ESTRUCTURA DE CONTROL DECISIVA IF: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        if (cambio > 0) {
            moneda10 = cambio / 10;
            cambio = cambio % 10;
        }
        
        if (cambio > 0) {
            moneda5 = cambio / 5;
            cambio = cambio % 5;
        }
        
        if (cambio > 0) {
            moneda2 = cambio / 2;
            cambio = cambio % 2;
        }
        
        if (cambio > 0) {
            moneda1 = cambio / 1;
            cambio = cambio % 1;
        }
        System.out.println("\nSu cambio es: \n" + moneda10 + " moneda(s) de 10. \n" + moneda5 + " moneda(s) de 5. \n" + moneda2 + " moneda(s) de 2. \n" + moneda1 + " moneda(s) de 1. \n");
    }
}     