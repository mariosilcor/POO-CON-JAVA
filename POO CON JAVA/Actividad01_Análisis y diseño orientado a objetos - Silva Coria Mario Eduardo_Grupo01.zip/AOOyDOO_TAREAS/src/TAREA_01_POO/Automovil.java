/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_01_POO;

/**
 *
 * @author Eduardo
 */
//PROGRAMA 01.
//Se define la Clase Automovil
public class Automovil {
    //Se definen los atributos de la Clase Automovil
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    String marca;
    String modelo;
    String color;
    int precio;
    boolean estado = false;
    
    //Se define el método Constructor de la Clase Automovil
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Automovil
    public Automovil() {
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO    
        this.marca = "TOYOTA";
        this.modelo = "Camry Hybrid 2022";
        this.color = "Negro";
        this.precio = 664300;
    }
    
    //Se definen los métodos que no tienen que ver con el método Constructor
    //Método Encender
    public void encender() {
        if (estado == true) {
            System.out.println("El automóvil ya está encendido");
        }
        else {
            estado = true;
            System.out.println("El automóvil se ha encendido");
        }
    }
    
    //Método Avanzar
    public void avanzar() {
        if (estado == true) {
            System.out.println("El automóvil está avanzando");
        }
        else {
            System.out.println("El automóvil no puede avanzar apagado");
        }
    }
    
    //Método Apagar
    public void apagar() {
        if (estado == false) {
            System.out.println("El automóvil ya está apagado");
        }
        else {
            estado = false;
            System.out.println("El automóvil se ha apagado");
        }
    }
    
    //Método main
    public static void main (String args []) { 
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR DE LA CLASE
        //Se define la creación del objeto
        Automovil toyota = new Automovil();
        
        System.out.println("ASIGNATURA.ANÁLISIS Y DISEÑO ORIENTADO A OBJETOS\nUNIDAD 01.POO\nTAREA 01.\n");
        
        //Atributos de mi objeto Toyota
        System.out.println("Atributos del objeto Toyota.");
        System.out.println("La marca del automóvil es: " + toyota.marca);
        System.out.println("El modelo del automóvil es: " + toyota.modelo);
        System.out.println("El color del automóvil es: " + toyota.color);
        System.out.println("El precio del automóvil es: $" + toyota.precio + " MXN\n");
        
        //Métodos de mi objeto Toyota
        System.out.println("Métodos del objeto Toyota.");
        toyota.encender();
        toyota.avanzar();
        toyota.apagar();
    }
}