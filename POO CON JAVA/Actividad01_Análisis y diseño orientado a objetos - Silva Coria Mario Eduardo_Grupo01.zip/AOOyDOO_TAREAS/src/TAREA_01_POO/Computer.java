/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_01_POO;

/**
 *
 * @author Eduardo
 */
//PROGRAMA 01.
//Se define la Clase Computadora
class Computer {
//Se define el Método Constructor de la Clase Computadora
    Computer() {
        System.out.println("Constructor de la clase Computadora.");
    }

//Se define el Método de la Clase Computadora
    void computer_method() {
        System.out.println("Nos vemos luego...");
    }
    
//Se define el Método main
public static void main(String[] args) {
//DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR DE LA CLASE
//Se crean las instancias de las Clases Computadora y Laptop
    Computer my = new Computer(); 
    Laptop your = new Laptop(); 
//Se invocan los métodos de las Clases Computadora y Laptop
    my.computer_method(); 
    your.laptop_method();
}
}