/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_01_POO;

/**
 *
 * @author Eduardo
 */
//PROGRAMA 02.
//Se define la Clase Laptop
class Laptop {
//Se define el Método Constructor de la Clase Laptop
    Laptop() {
        System.out.println("Constructor de la clase Laptop.");
    }
    
//Se define el Método de la Clase Laptop
    void laptop_method() {
        System.out.println("Nos vemos luego...");
    }
}