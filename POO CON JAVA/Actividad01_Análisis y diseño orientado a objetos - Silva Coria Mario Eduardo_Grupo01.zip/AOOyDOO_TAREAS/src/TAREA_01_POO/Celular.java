/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_01_POO;

/**
 *
 * @author Eduardo
 */
//PROGRAMA 02.
//Se define la Clase Celular
public class Celular {
    //Se definen los atributos de la Clase Celular
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    String marca;
    String modelo;
    String color;
    float precio;
    boolean estado = false;
    
    //Se define el método Constructor de la Clase Celular
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Celular
    public Celular() {
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO    
        this.marca = "SAMSUNG";
        this.modelo = "Galaxy A3(2016)";
        this.color = "Oro";
        this.precio = (float) 7684.25;
    }
    
    //Se definen los métodos que no tienen que ver con el método Constructor
    //Método Encender
    public void encender() {
        if (estado == true) {
            System.out.println("El celular ya está encendido");
        }
        else {
            estado = true;
            System.out.println("El celular se ha encendido");
        }
    }
    
    //Método Llamar
    public void llamar() {
        if (estado == true) {
            System.out.println("El celular realizará una llamada");
        }
        else {
            System.out.println("El celular no puede realizar una llamada si está apagado");
        }
    }
    
    //Método Apagar
    public void apagar() {
        if (estado == false) {
            System.out.println("El celular ya está apagado");
        }
        else {
            estado = false;
            System.out.println("El celular se ha apagado");
        }
    }
    
    //Método main
    public static void main (String args []) { 
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR DE LA CLASE
        //Se define la creación del objeto
        Celular samsung = new Celular();
        
         System.out.println("ASIGNATURA.ANÁLISIS Y DISEÑO ORIENTADO A OBJETOS\nUNIDAD 01.POO\nTAREA 01.\n");
        
        //Atributos de mi objeto Samsung
        System.out.println("Atributos del objeto Samsung.");
        System.out.println("La marca del celular es: " + samsung.marca);
        System.out.println("El modelo del celular es: " + samsung.modelo);
        System.out.println("El color del celular es: " + samsung.color);
        System.out.println("El precio del celular es: $" + samsung.precio + " MXN\n");
        
        //Métodos de mi objeto Samsung
        System.out.println("Métodos del objeto Samsung.");
        samsung.encender();
        samsung.llamar();
        samsung.apagar();
    }
}