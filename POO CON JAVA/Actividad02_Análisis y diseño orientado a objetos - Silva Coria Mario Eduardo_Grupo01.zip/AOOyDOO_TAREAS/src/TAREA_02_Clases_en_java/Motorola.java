/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_02_Clases_en_java;

/**
 *
 * @author Eduardo
 */

//Se define la Clase Motorola
public class Motorola {
    //Se definen los atributos de la Clase Motorola
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    String marca;
    String modelo;
    String color;
    float precio;
    boolean estado = false;
    
    //Se define el método Constructor de la Clase Motorola
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Motorola
    public Motorola() {
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO    
        this.marca = "MOTOROLA";
        this.modelo = "Moto G51";
        this.color = "Azul";
        this.precio = (float) 4430.00;
    }
    
    //Se definen los métodos que no tienen que ver con el método Constructor
    //Método Encender
    public void encender() {
        if (estado == true) {
            System.out.println("El celular ya está encendido");
        }
        else {
            estado = true;
            System.out.println("El celular se ha encendido");
        }
    }
    
    //Método Llamar
    public void llamar() {
        if (estado == true) {
            System.out.println("El celular realizará una llamada");
        }
        else {
            System.out.println("El celular no puede realizar una llamada si está apagado");
        }
    }
    
    //Método Apagar
    public void apagar() {
        if (estado == false) {
            System.out.println("El celular ya está apagado");
        }
        else {
            estado = false;
            System.out.println("El celular se ha apagado");
        }
    }
}