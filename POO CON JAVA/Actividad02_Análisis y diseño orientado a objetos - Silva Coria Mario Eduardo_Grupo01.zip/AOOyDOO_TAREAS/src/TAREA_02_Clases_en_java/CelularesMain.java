/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_02_Clases_en_java;

/**
 *
 * @author Eduardo
 */
//Se define la Clase CelularesMain
public class CelularesMain {
    
    public static void main (String args []) { //Método main
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR DE LA CLASE
        //Se define la creación de los objetos
        Samsung samsung = new Samsung();
        Apple apple = new Apple();
        Xiaomi xiaomi = new Xiaomi();
        LG lg = new LG();
        Motorola motorola = new Motorola();
        
        System.out.println("ASIGNATURA.ANÁLISIS Y DISEÑO ORIENTADO A OBJETOS\nUNIDAD 02.LAS CLASES EN JAVA\nTAREA 02.\n");
        
        //Atributos de mi objeto Samsung
        System.out.println("Atributos del objeto Samsung.");
        System.out.println("La marca del celular es: " + samsung.marca);
        System.out.println("El modelo del celular es: " + samsung.modelo);
        System.out.println("El color del celular es: " + samsung.color);
        System.out.println("El precio del celular es: $" + samsung.precio + " MXN\n");
        
        //Métodos de mi objeto Samsung
        System.out.println("Métodos del objeto Samsung.");
        samsung.encender();
        samsung.llamar();
        samsung.apagar();
        
        //Atributos de mi objeto Apple
        System.out.println("\nAtributos del objeto Apple.");
        System.out.println("La marca del celular es: " + apple.marca);
        System.out.println("El modelo del celular es: " + apple.modelo);
        System.out.println("El color del celular es: " + apple.color);
        System.out.println("El precio del celular es: $" + apple.precio + " MXN\n");
        
        //Métodos de mi objeto Apple
        System.out.println("Métodos del objeto Apple.");
        apple.encender();
        apple.llamar();
        apple.apagar();
        
        //Atributos de mi objeto Xiaomi
        System.out.println("\nAtributos del objeto Xiaomi.");
        System.out.println("La marca del celular es: " + xiaomi.marca);
        System.out.println("El modelo del celular es: " + xiaomi.modelo);
        System.out.println("El color del celular es: " + xiaomi.color);
        System.out.println("El precio del celular es: $" + xiaomi.precio + " MXN\n");
        
        //Métodos de mi objeto Xiaomi
        System.out.println("Métodos del objeto Xiaomi.");
        xiaomi.encender();
        xiaomi.llamar();
        xiaomi.apagar();
        
        //Atributos de mi objeto LG
        System.out.println("\nAtributos del objeto LG.");
        System.out.println("La marca del celular es: " + lg.marca);
        System.out.println("El modelo del celular es: " + lg.modelo);
        System.out.println("El color del celular es: " + lg.color);
        System.out.println("El precio del celular es: $" + lg.precio + " MXN\n");
        
        //Métodos de mi objeto LG
        System.out.println("Métodos del objeto LG.");
        lg.encender();
        lg.llamar();
        lg.apagar();
        
        //Atributos de mi objeto Motorola
        System.out.println("\nAtributos del objeto Motorola.");
        System.out.println("La marca del celular es: " + motorola.marca);
        System.out.println("El modelo del celular es: " + motorola.modelo);
        System.out.println("El color del celular es: " + motorola.color);
        System.out.println("El precio del celular es: $" + motorola.precio + " MXN\n");
        
        //Métodos de mi objeto Motorola
        System.out.println("Métodos del objeto Motorola.");
        motorola.encender();
        motorola.llamar();
        motorola.apagar();
    }
}