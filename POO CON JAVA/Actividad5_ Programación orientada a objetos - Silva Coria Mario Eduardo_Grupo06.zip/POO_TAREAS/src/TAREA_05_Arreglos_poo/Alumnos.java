/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_05_Arreglos_poo;

import java.util.*; //Librería que te permite trabajar con el método Scanner

/**
 *
 * @author Eduardo
 */
public class Alumnos {
    
    //Se definen los atributos de la Clase Alumnos
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    private String nombre, nombrearr, edadarr, generoarr;
    private int edad;
    private char genero;
    
    //Se define el método Constructor de la Clase Alumnos
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Alumnos
    public Alumnos() {
        
        //Para inicializar un atributo de tipo String se deben colocar comillas dobles sin espacios "";
        String nombre = "", nombrearr = "", edadarr = "", generoarr = ""; 
        int edad = 0;
        //Para inicializar un atributo de tipo char se deben colocar comillas simples con un espacio ' ';
        char genero = ' ';
    }
    
    //Este Constructor si va a recibir los argumentos que van a venir desde el Programa Principal_Alumnos
    //Constructor Sobrecargado, aquí estamos aplicando polimorfismo
    public Alumnos(String nomarr, String edarr, String genarr) {
        
        //Aquí se reciben los valores que se van a ocupar para el método ArregloDirecto
        nombrearr = nomarr;
        edadarr = edarr;
        generoarr = genarr;
    }
    
    //Este Constructor si va a recibir los argumentos que van a venir desde el Programa Principal_Alumnos
    //Constructor Sobrecargado, aquí estamos aplicando polimorfismo
    public Alumnos(String nom, int ed, char gen) {
        
        //Aquí se reciben los valores que se van a ocupar para el método ArregloTeclado
        nombre = nom;
        edad = ed;
        genero = gen;
    }
    
    //Se definen los métodos get y set
    //TODOS LOS MÉTODOS GET Y SET NOS SIRVEN PARA DESENCAPSULAR LOS MODIFICADORES DE ACCESO PRIVADO DE LA CLASE ALUMNOS
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nom) {
        this.nombre = nom;
    }
    
    public String getNombreDirecto() {
        return nombrearr;
    }
    
    public void setNombreDirecto(String nomarr) {
        this.nombrearr = nomarr;
    }
    
    public int getEdad() {
        return edad;
    }
    
    public void setEdad(int ed) {
        this.edad = ed;
    }
    
    public String getEdadDirecto() {
        return edadarr;
    }
    
    public void setEdadtDirecto(String edarr) {
        this.edadarr = edarr;
    }
    
    public char getGenero() {
        return genero;
    }
    
    public void setGenero(char gen) {
        this.genero = gen;
    }
    
    public String getGeneroDirecto() {
        return generoarr;
    }
    
    public void setGeneroDirecto(String genarr) {
        this.generoarr = genarr;
    }
    
    //Aquí forzamos al compilador a comprobar en tiempo de compilación que estamos sobrescribiendo un método para evitar errores en tiempo de ejecución
    @Override
    public String toString() {
        return nombrearr + edadarr + generoarr;
    }
    
    //Se definen los métodos que no tienen que ver con el método Constructor
    //Método ArregloDirecto
    public void ArregloDirecto() {
        
        System.out.println("Listado de alumnos de manera directa al arreglo:");
        //Aquí vamos a pedir todos los valores que se ingresen desde teclado
        //La variable de nuestro método Scanner es leer
        Scanner leer = new Scanner(System.in);
        
        //Aquí vamos a crear nuestro Arreglo de tipo lista de objetos
        //Se crea el Arreglo de tipo lista de objetos con tamaño de 4
        Alumnos arr[] = {
            new Alumnos("\nAlumno 1: \nNombre: Mario Eduardo Silva Coria", "\nEdad: 22", "\nSexo: M"),
            new Alumnos("\nAlumno 2: \nNombre: Luis Juan Rodríguez Mena", "\nEdad: 35", "\nSexo: M"),
            new Alumnos("\nAlumno 3: \nNombre: Erika Vianey López Méndez", "\nEdad: 35", "\nSexo: F"),
            new Alumnos("\nAlumno 4: \nNombre: Juan Luis Guerra Liceo", "\nEdad: 56", "\nSexo: M")};
        
        //Para inicializar un atributo de tipo String se deben colocar comillas dobles sin espacios "";
        String nombre = "";
        int edad = 0;
        //Para inicializar un atributo de tipo char se deben colocar comillas simples con un espacio ' ';
        char genero = ' ';
        
        //ESTRUCTURA DE CONTROL REPETITIVA FOR: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
    
    //Método ArregloTeclado
    public void ArregloTeclado() {
        
        //Aquí vamos a pedir todos los valores que se ingresen desde teclado
        //La variable de nuestro método Scanner es leer
        Scanner leer = new Scanner(System.in);
        //Aquí vamos a crear nuestro Arreglo de tipo objeto
        //Se crea el arreglo de tipo objeto con tamaño de 100
        Alumnos a[] = new Alumnos[100];
        int lista, sum;
        sum = 1;
        System.out.println("\nIngreso de datos de los alumnos a través del teclado:");
        System.out.println("¿Cuántos alumnos vas a ingresar?");
        //El valor ingresado desde teclado se guardará en el atributo lista
        lista = leer.nextInt();
        a = new Alumnos[lista];
        
        for (int i = 0; i < a.length; i++) {
            
            System.out.print("\nIngresa el nombre del alumno " + sum + ": ");
            //El valor ingresado desde teclado se guardará en el atributo nombre
            nombre = leer.next();  
            
            System.out.print("Ingresa la edad del alumno " + sum + ": ");
            //El valor ingresado desde teclado se guardará en el atributo edad
            edad = leer.nextInt();
            
            System.out.print("Ingresa el genero del alumno " + sum + ": ");
            //El valor ingresado desde teclado se guardará en el atributo genero
            genero = leer.next().charAt(0);
            
            //DESPUÉS DE PEDIR TODOS LOS VALORES DESDE TECLADO VAMOS A UTILIZAR EL MÉTODO NEXTLINE
            //EL MÉTODO NEXTLINE VA A RECONOCER LOS DEMÁS VALORES DE TIPO STRING QUE INGRESEMOS DESDE TECLADO
            leer.nextLine();
            //Aquí todos los valores que se pidieron desde teclado, ahora se tendrán que mandar como argumentos al Constructor Alumnos a través del arreglo de tipo objeto
            a[i] = new Alumnos(nombre, edad, genero);
            sum++;
        }
        System.out.println("\nLos alumnos que ingresaste por teclado son los siguientes: ");
        sum = 1;
        
        //ESTRUCTURA DE CONTROL REPETITIVA FOR: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        for (int i = 0; i < a.length; i++) {
            System.out.println("\nAlumno " + sum + " en el índice " + i + " del arreglo: " + "\nNombre: " + a[i].getNombre() + "\nEdad: " + a[i].getEdad() + "\nSexo: " + a[i].getGenero());
            sum++;
        }
    }
}