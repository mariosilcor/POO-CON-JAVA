/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_05_Arreglos_poo;

/**1
 *
 * @author Eduardo
 */
public class Principal_Alumnos {
    
    public static void main(String args[]) { //Método main
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR EN LA CLASE
        System.out.println("ASIGNATURA.PROGRAMACIÓN ORIENTADA A OBJETOS\nUNIDAD 05.ARREGLOS\nTAREA 05.\n");
        
        //Se define la creación del objeto alumno
        Alumnos alumno = new Alumnos();
        
        //Métodos de mi objeto alumno
        alumno.ArregloDirecto();
        alumno.ArregloTeclado();
    }
}