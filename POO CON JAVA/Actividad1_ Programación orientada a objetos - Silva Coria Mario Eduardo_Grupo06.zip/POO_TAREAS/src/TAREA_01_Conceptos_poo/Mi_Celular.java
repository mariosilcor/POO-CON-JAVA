/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_01_Conceptos_poo;

/**
 *
 * @author Eduardo
 */
public class Mi_Celular {
    
    //Se definen los atributos de la Clase Mi_Celular
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    String marca;
    String modelo;
    String color;
    float precio;
    
    //Se define el método Constructor de la Clase Mi_Celular
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Mi_Celular
    public Mi_Celular() {
        
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO    
        this.marca = "SAMSUNG";
        this.modelo = "Galaxy A3(2016)";
        this.color = "Oro";
        this.precio = (float) 7684.25;
    }
    
    //Se definen los métodos que no tienen que ver con el método Constructor
    //Método Encender
    public void encender() {
        System.out.println("El celular se está encendiendo");
    }
    
    //Método Llamar
    public void llamar() {
        System.out.println("El celular hará una llamada");
    }
    
    //Método Colgar
    public void colgar() {
        System.out.println("El celular terminó la llamada");
    }
    
    //Método Apagar
    public void apagar() {
        System.out.println("El celular se está apagando");
    }   
}