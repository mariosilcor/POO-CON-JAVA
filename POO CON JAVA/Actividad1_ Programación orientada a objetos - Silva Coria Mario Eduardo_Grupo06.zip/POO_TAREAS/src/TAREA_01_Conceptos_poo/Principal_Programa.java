/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_01_Conceptos_poo;

/**
 *
 * @author Eduardo
 */
public class Principal_Programa { //Nombre de la Clase
    public static void main (String args []) { //Método main
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR EN LA CLASE
        //Se define la creación del objeto
        Mi_Celular samsung = new Mi_Celular();
        
        System.out.println("ASIGNATURA.PROGRAMACIÓN ORIENTADA A OBJETOS\nUNIDAD 01.CONCEPTOS BÁSICOS DE LA POO\nTAREA 01.\n");
        
        //Atributos de mi objeto celular
        System.out.println("Atributos del objeto celular.");
        System.out.println("La marca del celular es: " + samsung.marca);
        System.out.println("El modelo del celular es: " + samsung.modelo);
        System.out.println("El color del celular es: " + samsung.color);
        System.out.println("El precio del celular es: $" + samsung.precio + " MXN\n");
        
        //Métodos de mi objeto celular
        System.out.println("Métodos del objeto celular.");
        samsung.encender();
        samsung.llamar();
        samsung.colgar();
        samsung.apagar();
    }
}