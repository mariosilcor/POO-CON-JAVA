/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_06_Herencia_y_polimorfismo_poo;

/**
 *
 * @author Eduardo
 */
public class SubClase_Pantalones extends SuperClase_Prenda{ //Esta es la SubClase Pantalones y va a poder heredar de la SuperClase Prenda
    //Estamos aplicando la Herencia con ayuda de la palabra reservada extends
    
    //Se definen los atributos de la SubClase Pantalones
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    private byte talla, largo;
    
    //Se definen los métodos get y set
    //TODOS LOS MÉTODOS GET Y SET NOS SIRVEN PARA DESENCAPSULAR LOS MODIFICADORES DE ACCESO PRIVADO DE LA SUBCLASE PANTALONES
    public byte getTalla() {
        return talla;
    }
    
    public void setTalla(byte talla) {
        this.talla = talla;
    }
    
    public byte getLargo() {
        return largo;
    }
    
    public void setLargo(byte largo) {
        this.largo = largo;
    }
    
    //Se define el método desplegarInformacion
    public void desplegarInformacion() {
        System.out.println("\nLa id de los pantalones es: " + (getId()*2)); 
        System.out.println("La descripción de los pantalones es: " + getDescripcion());
        System.out.println("La cantidad en existencia de los pantalones es: " + getExistencia());
        System.out.println("El precio de los pantalones es: " + getPrecio());
        System.out.println("La marca de los pantalones es: " + getMarca());
        System.out.println("La talla de los pantalones es: " + getTalla());
        System.out.println("El largo de los pantalones es: " + getLargo());
    }    
}