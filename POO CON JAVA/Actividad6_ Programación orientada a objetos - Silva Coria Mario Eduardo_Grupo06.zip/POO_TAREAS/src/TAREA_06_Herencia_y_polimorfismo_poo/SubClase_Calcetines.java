/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_06_Herencia_y_polimorfismo_poo;

/**
 *
 * @author Eduardo
 */
public class SubClase_Calcetines extends SuperClase_Prenda { //Esta es la SubClase Calcetines y va a poder heredar de la SuperClase Prenda
    //Estamos aplicando la Herencia con ayuda de la palabra reservada extends
    
    //Se definen los atributos de la SubClase Calcetines
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    private char codigoColor;
    
    //Se definen los métodos get y set
    //TODOS LOS MÉTODOS GET Y SET NOS SIRVEN PARA DESENCAPSULAR LOS MODIFICADORES DE ACCESO PRIVADO DE LA SUBCLASE CALCETINES
    public char getCodigoColor() {
        return codigoColor;
    }
    
    public void setCodigoColor(char codigoColor) {
        this.codigoColor = codigoColor;
    }
    
    //Se define el método desplegarInformacion
    public void desplegarInformacion() {
        System.out.println("\nLa id de los calcetines es: " + (getId()*4));
        System.out.println("La descripción de los calcetines es: " + getDescripcion());
        System.out.println("La cantidad en existencia de los calcetines es: " + getExistencia());
        System.out.println("El precio de los calcetines es: " + getPrecio());
        System.out.println("La marca de los calcetines es: " + getMarca());
        System.out.println("El código de color de los calcetines es: " + getCodigoColor());
    }
}