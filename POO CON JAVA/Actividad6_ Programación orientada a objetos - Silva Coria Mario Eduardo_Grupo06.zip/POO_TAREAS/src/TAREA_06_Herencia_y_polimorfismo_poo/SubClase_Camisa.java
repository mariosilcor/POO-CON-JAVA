/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_06_Herencia_y_polimorfismo_poo;

/**
 *
 * @author Eduardo
 */
public class SubClase_Camisa extends SuperClase_Prenda { //Esta es la SubClase Camisa y va a poder heredar de la SuperClase Prenda
    //Estamos aplicando la Herencia con ayuda de la palabra reservada extends
    
    //Se definen los atributos de la SubClase Camisa
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    private char codigoColor;
    private float cuello;
    private String talla;
    
    //Se definen los métodos get y set
    //TODOS LOS MÉTODOS GET Y SET NOS SIRVEN PARA DESENCAPSULAR LOS MODIFICADORES DE ACCESO PRIVADO DE LA SUBCLASE CAMISA
    public char getCodigoColor() {
        return codigoColor;
    }
    
    public void setCodigoColor(char codigoColor) {
        this.codigoColor = codigoColor;
    }
    
    public float getCuello() {
        return cuello;
    }
    
    public void setCuello(float cuello) {
        this.cuello = cuello;
    }
    
    public String getTalla() {
        return talla;
    }
    
    public void setTalla(String talla) {
        this.talla = talla;
    }
    
    //Se define el método desplegarInformacion
    public void desplegarInformacion() {
        System.out.println("\nLa id de la camisa es: " + (getId()*1)); 
        System.out.println("La descripción de la camisa es: " + getDescripcion());
        System.out.println("La cantidad en existencia de la camisa es: " + getExistencia());
        System.out.println("El precio de la camisa es: " + getPrecio());
        System.out.println("La marca de la camisa es: " + getMarca());
        System.out.println("El código de color de la camisa es: " + getCodigoColor());
        System.out.println("El cuello de la camisa es: " + getCuello());
        System.out.println("La talla de la camisa es: " + getTalla());
    }
}