/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_06_Herencia_y_polimorfismo_poo;

/**
 *
 * @author Eduardo
 */
public class SuperClase_Prenda { //Esta es la SuperClase Prenda y va a poder ser heredada a todas sus SubClases
    
    //Se definen los atributos de la SuperClase Prenda
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    int id = 0;
    private String descripcion, marca;
    private int existencia, contadorInstancia;
    private float precio;

    //Se definen los métodos get y set
    //TODOS LOS MÉTODOS GET Y SET NOS SIRVEN PARA DESENCAPSULAR LOS MODIFICADORES DE ACCESO PRIVADO DE LA SUPERCLASE PRENDA
    public int getId() {
        
        for(contadorInstancia = 1; contadorInstancia <= 3; contadorInstancia++) {
            id++;
            if (contadorInstancia % 3 == 0) {
            }
        }
        return id;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public int getExistencia() {
        return existencia;
    }
    
    public void setExistencia(int existencia) {
        this.existencia = existencia;
    }
    
    public float getPrecio() {
        return precio;
    }
    
    public void setPrecio(float precio) {
        this.precio = precio;
    }
    
    public String getMarca() {
        return marca;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    //Se define el método desplegarInformacion
    public void desplegarInformacion() {
        System.out.println("\nLa id del artículo es: " + (getId()*5)); 
        System.out.println("La descripción del artículo es: " + getDescripcion());
        System.out.println("La cantidad en existencia del artículo es: " + getExistencia());
        System.out.println("El precio del artículo es: " + getPrecio());
        System.out.println("La marca del artículo es: " + getMarca());
    }
}