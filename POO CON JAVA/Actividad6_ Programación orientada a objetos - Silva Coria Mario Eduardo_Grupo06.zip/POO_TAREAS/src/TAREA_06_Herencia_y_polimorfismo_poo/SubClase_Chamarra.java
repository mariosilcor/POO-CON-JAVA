/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_06_Herencia_y_polimorfismo_poo;

/**
 *
 * @author Eduardo
 */
public class SubClase_Chamarra extends SuperClase_Prenda { //Esta es la SubClase Chamarra y va a poder heredar de la SuperClase Prenda
    //Estamos aplicando la Herencia con ayuda de la palabra reservada extends
    
    //Se definen los atributos de la SubClase Chamarra
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    private byte talla;
    private String material;
    
    //Se definen los métodos get y set
    //TODOS LOS MÉTODOS GET Y SET NOS SIRVEN PARA DESENCAPSULAR LOS MODIFICADORES DE ACCESO PRIVADO DE LA SUBCLASE CHAMARRA
    public byte getTalla() {
        return talla;
    }
    
    public void setTalla(byte talla) {
        this.talla = talla;
    }
    
    public String getMaterial() {
        return material;
    }
    
    public void setMaterial(String material) {
        this.material = material;
    }
    
    //Se define el método desplegarInformacion
    public void desplegarInformacion() {
        System.out.println("\nLa id de la chamarra es: " + (getId()*3)); 
        System.out.println("La descripción de la chamarra es: " + getDescripcion());
        System.out.println("La cantidad en existencia de la chamarra es: " + getExistencia());
        System.out.println("El precio de la chamarra es: " + getPrecio());
        System.out.println("La marca de la chamarra es: " + getMarca());
        System.out.println("La talla de la chamarra es: " + getTalla());
        System.out.println("La chamarra está hecha con: " + getMaterial());
    }    
}