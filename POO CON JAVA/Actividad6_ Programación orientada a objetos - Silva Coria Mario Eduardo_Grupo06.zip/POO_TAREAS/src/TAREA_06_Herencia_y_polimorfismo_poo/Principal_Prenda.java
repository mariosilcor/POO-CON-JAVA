/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_06_Herencia_y_polimorfismo_poo;

/**
 *
 * @author Eduardo
 */
public class Principal_Prenda {
    
    public static void main(String args[]) { //Método main
        
        System.out.println("ASIGNATURA.PROGRAMACIÓN ORIENTADA A OBJETOS\nUNIDAD 06.HERENCIA Y POLIMORFISMO\nTAREA 06.\n");
        System.out.println("Bienvenido a la Tienda Departamental de Liverpool.");
        
        //Se define la creación del objeto camisa
        SubClase_Camisa camisa = new SubClase_Camisa();
        //Métodos set de mi objeto camisa
        camisa.setDescripcion("Camisa De Vestir Manga Larga");
        camisa.setExistencia(150);
        camisa.setPrecio((float)599.99);
        camisa.setMarca("Calvin Klein");
        camisa.setCodigoColor('W');
        camisa.setCuello((float)15.5);
        camisa.setTalla("Mediana");
        //Método de mi objeto camisa
        camisa.desplegarInformacion();
        
        //Se define la creación del objeto pantalones
        SubClase_Pantalones pantalones = new SubClase_Pantalones();
        //Métodos set de mi objeto pantalones
        pantalones.setDescripcion("Pantalones De Mezclilla Regulares");
        pantalones.setExistencia(240);
        pantalones.setPrecio((float)475.99);
        pantalones.setMarca("Lee");
        pantalones.setTalla((byte)28);
        pantalones.setLargo((byte)32);
        //Método de mi objeto pantalones
        pantalones.desplegarInformacion();
        
        //Se define la creación del objeto chamarra
        SubClase_Chamarra chamarra = new SubClase_Chamarra();
        //Métodos set de mi objeto chamarra
        chamarra.setDescripcion("Chamarra Estilo Cazadora");
        chamarra.setExistencia(80);
        chamarra.setPrecio((float)1309.99);
        chamarra.setMarca("Puma");
        chamarra.setTalla((byte)38);
        chamarra.setMaterial("Poliéster");
        //Método de mi objeto chamarra
        chamarra.desplegarInformacion();
        
        //Se define la creación del objeto calcetines
        SubClase_Calcetines calcetines = new SubClase_Calcetines();
        //Métodos set de mi objeto calcetines
        calcetines.setDescripcion("Calcetines Clásicos Acolchonados");
        calcetines.setExistencia(415);
        calcetines.setPrecio((float)299.99);
        calcetines.setMarca("Adidas");
        calcetines.setCodigoColor('X');
        //Método de mi objeto calcetines
        calcetines.desplegarInformacion();
        
        //Se define la creación del objeto prenda
        SuperClase_Prenda prenda = new SuperClase_Prenda();
        //Métodos set de mi objeto prenda
        prenda.setDescripcion("- Sin Descripción -");
        prenda.setExistencia(0);
        prenda.setPrecio((float)0.00);
        prenda.setMarca("- Sin Datos -");
        //Método de mi objeto prenda
        prenda.desplegarInformacion();
    }
}