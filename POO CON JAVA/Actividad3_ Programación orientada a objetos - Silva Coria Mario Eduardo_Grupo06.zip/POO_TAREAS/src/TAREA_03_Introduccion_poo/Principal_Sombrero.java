/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_03_Introduccion_poo;

/**
 *
 * @author Eduardo
 */
public class Principal_Sombrero {
    public static void main (String args []) { //Método main
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR EN LA CLASE
        //Se define la creación del objeto
        Mi_Sombrero sombrero1 = new Mi_Sombrero();
        Mi_Sombrero sombrero2 = new Mi_Sombrero();
        Mi_Sombrero sombrero3 = new Mi_Sombrero();
        
        System.out.println("ASIGNATURA.PROGRAMACIÓN ORIENTADA A OBJETOS\nUNIDAD 03.INTRODUCCIÓN A LA POO\nTAREA 03.\n");
        
        //Atributos de mi objeto sombrero1
        System.out.println("Atributos del objeto sombrero1.");
        System.out.println("La ID del sombrero es: " + sombrero1.idSombrero1);
        System.out.println("El modelo del sombrero es: " + sombrero1.modelo1);
        System.out.println("El color del sombrero es: " + sombrero1.color1);
        System.out.println("La talla del sombrero es: " + sombrero1.talla1 + "\n");
        
        //Atributos de mi objeto sombrero2
        System.out.println("Atributos del objeto sombrero2.");
        System.out.println("La ID del sombrero es: " + sombrero2.idSombrero2);
        System.out.println("El modelo del sombrero es: " + sombrero2.modelo2);
        System.out.println("El color del sombrero es: " + sombrero2.color2);
        System.out.println("La talla del sombrero es: " + sombrero2.talla2 + "\n");
        
        //Atributos de mi objeto sombrero3
        System.out.println("Atributos del objeto sombrero3.");
        System.out.println("La ID del sombrero es: " + sombrero3.idSombrero3);
        System.out.println("El modelo del sombrero es: " + sombrero3.modelo3);
        System.out.println("El color del sombrero es: " + sombrero3.color3);
        System.out.println("La talla del sombrero es: " + sombrero3.talla3 + "\n");
        
        //Métodos de mi objeto sombrero2
        System.out.println("Métodos del objeto sombrero2.");
        sombrero2.descolgar();
        sombrero2.poner();
        sombrero2.quitar();
        sombrero2.limpiar();
        sombrero2.colgar();
    }
}