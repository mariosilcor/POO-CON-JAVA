/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_03_Introduccion_poo;

/**
 *
 * @author Eduardo
 */
public class Mi_Sombrero {
    
    //Se definen los atributos de la Clase Mi_Sombrero
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    int idSombrero1, idSombrero2, idSombrero3;
    String modelo1, modelo2, modelo3;
    String color1, color2, color3;
    String talla1, talla2, talla3;
    
    //Se define el método Constructor de la Clase Mi_Sombrero
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Mi_Sombrero
    public Mi_Sombrero() {
        
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO    
        this.idSombrero1 = 202201;
        this.modelo1 = "Adidas";
        this.color1 = "Blanco";
        this.talla1 = "Mediana";
        this.idSombrero2 = 202202;
        this.modelo2 = "Nike";
        this.color2 = "Negro";
        this.talla2 = "Mediana";
        this.idSombrero3 = 202203;
        this.modelo3 = "Puma";
        this.color3 = "Gris";
        this.talla3 = "Mediana";
    }
    
    //Se definen los métodos que no tienen que ver con el método Constructor
    //Método Descolgar
    public void descolgar() {
        System.out.println("El sombrero de la marca " + modelo2 + " ha sido descolgado");
    }
    
    //Método Poner
    public void poner() {
        System.out.println("El sombrero de la marca " + modelo2 + " se pusó en la cabeza de su dueño");
    }
    
    //Método Quitar
    public void quitar() {
        System.out.println("El sombrero de la marca " + modelo2 + " se quitó de la cabeza de su dueño");
    }
    
    //Método Limpiar
    public void limpiar() {
        System.out.println("El sombrero de la marca " + modelo2 + " ha sido limpiado");
    }
    
    //Método Colgar
    public void colgar() {
        System.out.println("El sombrero de la marca " + modelo2 + " ha sido colgado");
    }   
}