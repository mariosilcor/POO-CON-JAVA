/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_04_Entradas_y_salidas;

import java.io.FileWriter; //Librería que te permite escribir secuencias de caracteres en un archivo
import java.io.IOException; //Librería que te permite trabajar con excepciones para el acceso a los archivos
import java.util.Scanner; //Librería que te permite trabajar con el método Scanner

/**
 *
 * @author Eduardo
 */
//Se define la Clase Estacionamiento
public class Estacionamiento {
    
    //Se definen los atributos de la Clase Estacionamiento
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    int moneda10, moneda5, moneda2, moneda1, pago, cambio, opcion, costo, horas;
    
    //Se define el método Constructor de la Clase Estacionamiento
    //El Constructor debe tener el mismo nombre de la Clase, en este caso la Clase se llama Estacionamiento
    public Estacionamiento(int costo, int horas) {
        
        //LA PALABRA RESERVADA THIS EN JAVA SIRVE PARA QUE PODAMOS DIFERENCIAR ENTRE UN ATRIBUTO Y UN ARGUMENTO 
        this.costo = costo;
        this.horas = horas;
      
    }
    
    public void Pagos() { //Aquí vamos a trabajar con el método que calcule los pagos del estacionamiento
        
        pago = 0; //Inicializando un atributo de tipo int sin ningún valor
        opcion = 0; //Inicializando un atributo de tipo int sin ningún valor
        
        //Aquí vamos a pedir todos los valores que se ingresen desde teclado
        //La variable de nuestro método Scanner es leer
        Scanner leer = new Scanner(System.in);
      
        //ESTRUCTURA DE CONTROL REPETITIVA WHILE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        while (!(pago >= costo)) {
            System.out.println("\nUsted debe: $" + (costo - pago) + ". Elige la opción para tu forma de pago: \n1)$100 \t2)$50 \t3)$20 \n4)$10 \t5)$5 \t6)$2 \t7)$1");
            opcion = leer.nextInt(); //El valor ingresado desde teclado se guardará en el atributo opcion
            
            //ESTRUCTURA DE CONTROL DECISIVA IF ELSEIF ELSE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
            if (opcion == 1) {
                pago = pago + 100;
            }
            
            else {
                if (opcion == 2) {
                    pago = pago + 50;
                }
                
                else {
                    if (opcion == 3) {
                        pago = pago + 20;
                    }
                    
                    else {
                        if (opcion == 4) {
                            pago = pago + 10;
                        }
                        
                        else {
                            if (opcion == 5) {
                                pago = pago + 5;
                            }
                            
                            else {
                                if (opcion == 6) {
                                    pago = pago + 2;
                                }
                                
                                else {
                                    if (opcion == 7) {
                                        pago = pago + 1;
                                    }
                                    
                                    else {
                                        System.out.println("Opción incorrecta");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void Cambios() { //Aquí vamos a trabajar con el método que calcule los cambios del estacionamiento
        
        cambio = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda10 = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda5 = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda2 = 0; //Inicializando un atributo de tipo int sin ningún valor
        moneda1 = 0; //Inicializando un atributo de tipo int sin ningún valor
        cambio = pago - costo;
        
        //ESTRUCTURA DE CONTROL DECISIVA IF: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        if (cambio > 0) {
            moneda10 = cambio / 10;
            cambio = cambio % 10;
        }
        
        if (cambio > 0) {
            moneda5 = cambio / 5;
            cambio = cambio % 5;
        }
        
        if (cambio > 0) {
            moneda2 = cambio / 2;
            cambio = cambio % 2;
        }
        
        if (cambio > 0) {
            moneda1 = cambio / 1;
            cambio = cambio % 1;
        }
        System.out.println("\nSu cambio es: \n" + moneda10 + " moneda(s) de 10. \n" + moneda5 + " moneda(s) de 5. \n" + moneda2 + " moneda(s) de 2. \n" + moneda1 + " moneda(s) de 1. \n");
    }
    
    public static void main(String[] args) throws IOException { //Método main
       
       //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR EN LA CLASE
       System.out.println("ASIGNATURA.ANÁLISIS Y DISEÑO ORIENTADO A OBJETOS\nUNIDAD 04.ENTRADAS Y SALIDAS EN JAVA\nTAREA 04.\n");
       
       //Aquí vamos a definir los atributos
       int costo, horas, contador = 0;
       //Para inicializar un atributo de tipo char se deben colocar comillas simples con un espacio ' '
       char menu = ' ';
       //Para inicializar un atributo de tipo String se deben colocar comillas dobles
       String nombre = "";
       //Aquí vamos a pedir todos los valores que se ingresen desde teclado
       //Las variables de nuestro método Scanner son leerInt, leerChar y leerString
       Scanner leerInt = new Scanner(System.in);
       Scanner leerChar = new Scanner(System.in);
       Scanner leerString = new Scanner(System.in);
       
       //Se declara y se asigna una variable de tipo String
       String archivo = "BASE DE DATOS DEL ESTACIONAMIENTO DE SIX FLAGS MEXICO EN UN ARCHIVO DE TEXTO.";
       
       //Escritura de ficheros
        try {
            //Se declara un stream o una secuencia de bytes con el nombre fichero
            FileWriter fichero = new FileWriter("Registros_capturados.txt");
            fichero.write(archivo); //Método que permite escribir en el archivo

       //ESTRUCTURA DE CONTROL REPETITIVA DO-WHILE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
       do { 
           contador++; //Contador
           costo = 0; //Inicializando un atributo de tipo int sin ningún valor
           horas = 0; //Inicializando un atributo de tipo int sin ningún valor
           System.out.println("Bienvenido al Estacionamiento de Six Flags México.\nTarifa: $30.00 por hora.");
           System.out.println("Por favor, introduce tu nombre completo: ");
           nombre = leerString.nextLine(); //El valor ingresado desde teclado se guardará en el atributo nombre
           System.out.println("\nUsuario Número. " + contador + "\tNombre del usuario: " + nombre);
           System.out.println("\n¿Cuántas horas utilizaste el estacionamiento?");
           horas = leerInt.nextInt(); //El valor ingresado desde teclado se guardará en el atributo horas
           archivo = "\nUsuario Número. " + contador + "\tNombre del usuario: " + nombre + "\tHoras utilizadas en el estacionamiento: " + horas;
           fichero.write(archivo); //Método que permite escribir en el archivo
           costo = horas * 30;
           
           //ESTRUCTURA DE CONTROL DECISIVA IF: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
           if (costo > 999) {
               costo = 999;
           }
           
           //Se define la creación del objeto parking
           Estacionamiento parking = new Estacionamiento(costo, horas);

           //Métodos de mi objeto parking
           parking.Pagos();
           parking.Cambios();
           System.out.print("Por favor, ingrese la tecla 's' para ingresar al sistema del estacionamiento: ");
           menu = leerChar.next().charAt(0); //El valor ingresado desde teclado se guardará en el atributo menu
        }
       while (menu == 's');
       fichero.close(); //Método que permite cerrar el archivo
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    }
}