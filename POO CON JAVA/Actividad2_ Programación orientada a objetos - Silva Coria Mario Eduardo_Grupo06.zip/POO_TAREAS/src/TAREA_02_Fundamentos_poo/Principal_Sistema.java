/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_02_Fundamentos_poo;

/**
 *
 * @author Eduardo
 */
public class Principal_Sistema {
    public static void main (String args []) { //Método main
        
        //DENTRO DEL MÉTODO MAIN TENDREMOS TODO EL CÓDIGO A EJECUTAR EN LA CLASE
        //Se define la creación del objeto
        Casa_Cambio divisa = new Casa_Cambio();
        
        System.out.println("ASIGNATURA.PROGRAMACIÓN ORIENTADA A OBJETOS\nUNIDAD 02.FUNDAMENTOS DE LA POO\nTAREA 02.\n");
        
        //Método de mi objeto divisa
        divisa.entregar();
    }
}