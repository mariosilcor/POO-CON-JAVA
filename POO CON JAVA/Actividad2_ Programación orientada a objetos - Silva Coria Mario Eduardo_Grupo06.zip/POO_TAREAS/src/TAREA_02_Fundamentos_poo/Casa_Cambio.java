/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TAREA_02_Fundamentos_poo;

import java.util.*; //Librería que nos permite usar el método Scanner

/**
 *
 * @author Eduardo
 */
public class Casa_Cambio {
    
    //Se definen los atributos de la Clase Casa_Cambio
    //LOS ATRIBUTOS SON LAS CARACTERISTICAS DE NUESTRO OBJETO
    int opc; //Esta variable guardará el valor ingresado desde el teclado
    float cambio; //Esta variable guardará el valor ingresado desde el teclado
    float total; //Esta variable será el resultado de operar cambio con la cotización de la divisa
    
    //Método Entregar
    public void entregar() {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Sistema de Casa de cambio\n1. USD A MXN\n2. MXN A USD\n3. CAD A MXN\n4. MXN A CAD\n5. EUR A MXN\n6. MXN A EUR");
        System.out.print("\nIngrese una opción: ");
        //El valor ingresado desde teclado se guardará en el atributo opc
        opc = sc.nextInt();
        
        //ESTRUCTURA DE CONTROL DECISIVA IF ELSEIF ELSE: ESTAMOS CONTROLANDO EL FLUJO DEL PROGRAMA
        if (opc == 1) {
        System.out.print("\nIntroduce la cantidad de Dólares estadounidenses a cambiar: ");
        //El valor ingresado desde teclado se guardará en el atributo cambio
        cambio = sc.nextFloat();
        total = (float) (cambio * 19.864265f);
        System.out.println("Debes entregarle al cliente la cantidad de: $" + total + " MXN\nGracias por utilizar el Sistema Casa de Cambio");
        } 
        
        else if (opc == 2) {
        System.out.print("\nIntroduce la cantidad de Pesos mexicanos a cambiar: ");
        //El valor ingresado desde teclado se guardará en el atributo cambio
        cambio = sc.nextFloat();
        total = (float) (cambio * 0.05034188f);
        System.out.println("Debes entregarle al cliente la cantidad de: $" + total + " USD\nGracias por utilizar el Sistema Casa de Cambio");
        } 
        
        else if (opc == 3) {
        System.out.print("\nIntroduce la cantidad de Dólares canadienses a cambiar: ");
        //El valor ingresado desde teclado se guardará en el atributo cambio
        cambio = sc.nextFloat();
        total = (float) (cambio * 15.864847f);
        System.out.println("Debes entregarle al cliente la cantidad de: $" + total + " MXN\nGracias por utilizar el Sistema Casa de Cambio");
        } 
        
        else if (opc == 4) {
        System.out.print("\nIntroduce la cantidad de Pesos mexicanos a cambiar: ");
        //El valor ingresado desde teclado se guardará en el atributo cambio
        cambio = sc.nextFloat();
        total = (float) (cambio * 0.06303244f);
        System.out.println("Debes entregarle al cliente la cantidad de: $" + total + " CAD\nGracias por utilizar el Sistema Casa de Cambio");
        } 
        
        else if (opc == 5) {
        System.out.print("\nIntroduce la cantidad de Euros a cambiar: ");
        //El valor ingresado desde teclado se guardará en el atributo cambio
        cambio = sc.nextFloat();
        total = (float) (cambio * 21.942608f);
        System.out.println("Debes entregarle al cliente la cantidad de: $" + total + " MXN\nGracias por utilizar el Sistema Casa de Cambio");
        }
        
        else if (opc == 6) {
        System.out.print("\nIntroduce la cantidad de Pesos mexicanos a cambiar: ");
        //El valor ingresado desde teclado se guardará en el atributo cambio
        cambio = sc.nextFloat();
        total = (float) (cambio * 0.045573435f);
        System.out.println("Debes entregarle al cliente la cantidad de: €" + total + " EUR\nGracias por utilizar el Sistema Casa de Cambio");
        }
        
        else {
        System.out.println("Ingresaste otra opción\nGracias por utilizar el Sistema Casa de Cambio");
        }
    }
}